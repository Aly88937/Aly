// scripts.js

document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Merci pour votre message. Nous vous contacterons bientôt !");
});

// Chargement de la carte Google Maps
function initMap() {
    var location = { lat: 48.8566, lng: 2.3522 }; // Coordonnées de Paris (à ajuster selon votre emplacement)
    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: location
    });
    var marker = new google.maps.Marker({
        position: location,
        map: map
    });
}

// Ajout de l'événement de chargement de la carte
document.addEventListener("DOMContentLoaded", function() {
    initMap();
});
